create table order_items(order_id int, pro_id int, quan int);
insert into order_items values(1,1,2),(1,3,1),(2,2,1),(2,4,1),(2,6,2),(3,5,1),(3,7,1),(3,10,3),(4,8,2),(4,9,2);
select * from order_items;
select count(*), pro_id from order_items group by pro_id;
select order_id, sum(quan) from order_items group by order_id order by order_id;
select order_id,pro_id from order_items  where quan>1;
select sum(quan),pro_id from order_items group by pro_id order by sum(quan) desc;


Output:

order_id	pro_id	quan
1	1	2
1	3	1
2	2	1
2	4	1
2	6	2
3	5	1
3	7	1
3	10	3
4	8	2
4	9	2
count(*)	pro_id
1	1
1	3
1	2
1	4
1	6
1	5
1	7
1	10
1	8
1	9
order_id	sum(quan)
1	3
2	4
3	5
4	4
order_id	pro_id
1	1
2	6
3	10
4	8
4	9
sum(quan)	pro_id
3	10
2	1
2	6
2	8
2	9
1	3
1	2
1	4
1	5
1	7