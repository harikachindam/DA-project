
create table products(product_id int, name varchar(20),price decimal,category varchar(20), rating int );
insert into products values(1,'Apple iPhone 12',799,'Electronis',4),(2,'Samsung Galaxy S21',899,'Electronis',5),(3,'Sony 55 TV',1299,'Electronis',4),(4,'Sony Playstation 5',499,'Electronis',5),(5,'Dell XPS 13',1199,'Computers',4),(6,'MacBook Pro 13',1299,'Computers',5),(7,'Nike Air Zoom',129,'Footwear',4),(8,'Adidas Ultraboost',149,'Footwear',5),(9,'Calvin Klein T-Shirt',29.99,'Clothing',3),(10,'Levis Jeans',59.99,'Clothing',4);
select * from products;
select name,price from products where rating=5 order by price asc;
select avg(price),category from products group by category order by category;
select name,category from products where price>1000 order by category;
select count(*),category from products  where rating>=4 group by category;
select name,rating from products  where name like '%al%' order by rating desc; 
