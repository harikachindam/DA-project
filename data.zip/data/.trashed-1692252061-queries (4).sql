
CREATE TABLE vals (num int);
insert into vals VALUES(-9),(-8),(-10),(2);
select abs(num) from vals;
SELECT power(max(abs(num)),max(num)) from vals;

select round(10.6857,3);
select sqrt(64);
select exp(2) "expon" from dual;
select greatest(1,45,323,134,2324)"great" from dual;
select least(3,23,324,2423)"least" from dual;
select mod(9,2) from dual;
select truncate(12.634,2) from dual;
select floor(34.56) from dual;
select ceil(34.56) from dual;
select lower('Varsha Netha');
select upper('Varsha Netha');
#select cap('dora') from dual;
select substr("Varshanakka",-7,3);
select ascii('V');
select instr("Hello World",'o');
select length('  dora  ');
#select ltrim('arshaneth','a') from dual;
#select rtrim('arshaneth','a') from dual;
select rpad('var',5,'s');
select lpad('var',5,'s');
#select vsize('varsha');
#select to_number('34') from dual;
#select to_char(45);
#select add_months('02-feb-08',4)









abs(num)
9
8
10
2
power(max(abs(num)),max(num))
100
round(10.6857,3)
10.686
sqrt(64)
8
expon
7.38905609893065
great
2324
least
3
mod(9,2)
1
truncate(12.634,2)
12.63
floor(34.56)
34
ceil(34.56)
35
lower('Varsha Netha')
varsha netha
upper('Varsha Netha')
VARSHA NETHA
substr("Varshanakka",-7,3)
han
ascii('V')
86
instr("Hello World",'o')
5
length('  dora  ')
8
rpad('var',5,'s')
varss
lpad('var',5,'s')
ssvar
