create table products(p_id int, p_name varchar(20),price int,c_id int);
insert into products values(1,'iphone',999,1),(2,'samsung',899,1),(3,'lg',699,1),(4,'dell',799,2),(5,'hp',599,2),(6,'lenovo',699,2),(7,'nike',149,3),(8,'adidas',129,3),(9,'puma',109,3);
select * from products;

create table categories(c_id int,c_name varchar(20));
insert into categories values(1,'mobile'),(2,'laptop'),(3,'shoes');
select * from categories;

create table orders(o_id int,cu_name varchar(20),p_id int,quan int,order_date date);
insert into orders values(1,'john smith',1,2,'2022-01-01'),(2,'lisa jones',4,1,'2022-01-02'),(3,'mike brown',7,3,'2022-01-03'),(4,'sarah lee',2,1,'2022-01-04'),(5,'tom davis',3,4,'2022-01-05');
select * from orders;


create table departments(dept_id int primary key, dept_name varchar(50) not null);
#desc departments;

create table employees(emp_id int primary key, f_name varchar(50) not null, l_name varchar(50) not null, d_id int not null, hire_date date not null, salary decimal(10,2) not null,constraint fk_department foreign key(d_id) references departments(dept_id));
desc employees;

