create table A(pk int, val varchar(20));
insert into A values(1,'fox'),(2,'cop'),(3,'taxi'),(6,'wshngton'),(7,'dell'),(5,'arizona'),(4,'lincoln'),(10,'lucent');
select * from A;

create table B(pk int, val varchar(20));
insert into B values(1,'trot'),(2,'car'),(3,'cab'),(6,'monument'),(7,'pc'),(8,'microsoft'),(9,'apple'),(11,'scotch');
select * from B;

select * from A inner join B on A.pk=B.pk;
#select * from A,B where A.pk=B.pk;


select * from A left outer join B on A.pk=B.pk;

select * from A right outer join B on A.pk=B.pk;

select * from A left outer join B on A.pk=B.pk
union
select * from A right outer join B on A.pk=B.pk;

select * from A left outer join B on A.pk=B.pk where B.pk is null;

select * from A right outer join B on A.pk=B.pk where A.pk is null;

select * from A left outer join B on A.pk=B.pk where B.pk is null
union
select * from A right outer join B on A.pk=B.pk where A.pk is null;

select * from A cross join B;



Output:

pk	val
1	fox
2	cop
3	taxi
6	wshngton
7	dell
5	arizona
4	lincoln
10	lucent
pk	val
1	trot
2	car
3	cab
6	monument
7	pc
8	microsoft
9	apple
11	scotch
pk	val	pk	val
1	fox	1	trot
2	cop	2	car
3	taxi	3	cab
6	wshngton	6	monument
7	dell	7	pc
pk	val	pk	val
1	fox	1	trot
2	cop	2	car
3	taxi	3	cab
6	wshngton	6	monument
7	dell	7	pc
5	arizona	NULL	NULL
4	lincoln	NULL	NULL
10	lucent	NULL	NULL
pk	val	pk	val
1	fox	1	trot
2	cop	2	car
3	taxi	3	cab
6	wshngton	6	monument
7	dell	7	pc
NULL	NULL	8	microsoft
NULL	NULL	9	apple
NULL	NULL	11	scotch
pk	val	pk	val
1	fox	1	trot
2	cop	2	car
3	taxi	3	cab
6	wshngton	6	monument
7	dell	7	pc
5	arizona	NULL	NULL
4	lincoln	NULL	NULL
10	lucent	NULL	NULL
NULL	NULL	8	microsoft
NULL	NULL	9	apple
NULL	NULL	11	scotch
pk	val	pk	val
5	arizona	NULL	NULL
4	lincoln	NULL	NULL
10	lucent	NULL	NULL
pk	val	pk	val
NULL	NULL	8	microsoft
NULL	NULL	9	apple
NULL	NULL	11	scotch
pk	val	pk	val
5	arizona	NULL	NULL
4	lincoln	NULL	NULL
10	lucent	NULL	NULL
NULL	NULL	8	microsoft
NULL	NULL	9	apple
NULL	NULL	11	scotch
pk	val	pk	val
10	lucent	1	trot
4	lincoln	1	trot
5	arizona	1	trot
7	dell	1	trot
6	wshngton	1	trot
3	taxi	1	trot
2	cop	1	trot
1	fox	1	trot
10	lucent	2	car
4	lincoln	2	car
5	arizona	2	car
7	dell	2	car
6	wshngton	2	car
3	taxi	2	car
2	cop	2	car
1	fox	2	car
10	lucent	3	cab
4	lincoln	3	cab
5	arizona	3	cab
7	dell	3	cab
6	wshngton	3	cab
3	taxi	3	cab
2	cop	3	cab
1	fox	3	cab
10	lucent	6	monument
4	lincoln	6	monument
5	arizona	6	monument
7	dell	6	monument
6	wshngton	6	monument
3	taxi	6	monument
2	cop	6	monument
1	fox	6	monument
10	lucent	7	pc
4	lincoln	7	pc
5	arizona	7	pc
7	dell	7	pc
6	wshngton	7	pc
3	taxi	7	pc
2	cop	7	pc
1	fox	7	pc
10	lucent	8	microsoft
4	lincoln	8	microsoft
5	arizona	8	microsoft
7	dell	8	microsoft
6	wshngton	8	microsoft
3	taxi	8	microsoft
2	cop	8	microsoft
1	fox	8	microsoft
10	lucent	9	apple
4	lincoln	9	apple
5	arizona	9	apple
7	dell	9	apple
6	wshngton	9	apple
3	taxi	9	apple
2	cop	9	apple
1	fox	9	apple
10	lucent	11	scotch
4	lincoln	11	scotch
5	arizona	11	scotch
7	dell	11	scotch
6	wshngton	11	scotch
3	taxi	11	scotch
2	cop	11	scotch
1	fox	11	scotch