create table customers(cus_id int primary key, name varchar(20),email varchar(30),addr varchar(30));
insert into customers values(4,'Emily Johnson','emily@example.com','987 Oak Lane'),(5,'Michael Brown','michael@example.com','321 Elm Avenue'),(6,'Sarah Davis','sarah@example.com','654 Main Street'),(7,'Jessica Lee','jessica@example.com','123 Maple Road'),(8,'Brain Wilson','brain@example.com','456 Pine Street');


create table orders(ord_id int primary key, cus_id int, ord_date date, tamount decimal);
#alter table orders add constraint fk_ord foreign key(cus_id) references customers(cus_id);

insert into orders values(4,2,'2023-06-05',120),(5,4,'2023-06-06',45),(6,3,'2023-06-07',80),(7,5,'2023-06-09',65),(8,6,'2023-06-10',95);


create table products(p_id int primary key, p_name varchar(20), description varchar(50), price decimal);
insert into products values(4,'Hoodie','Warm, available in multiple colors',29.99),(5,'Dress','Elegant for special occasion',59.99),(6,'Watch','Stylish with leather strap',99.99),(7,'Backpack','Spacious for everyday use',49.99),(8,'Sunglasses','UV protection',24.99);


create table order_items(ord_item_id int primary key, ord_id int, p_id int, quan int, unit_price decimal);
#alter table orders add constraint foreign key(ord_id) references orders(ord_id);
#alter table orders add constraint foreign key(p_id) references products(p_id);
insert into order_items values(5,4,2,2,39.99),(6,4,3,1,49.99),(7,5,4,1,29.99),(8,6,6,1,99.99),(9,6,8,2,24.99);


select p_name from products where price<=50;
select ord_id from orders where ord_date>='2023-06-05';
select name,count(ord_id) from customers natural join orders group by name;
select avg(price),p_name from products group by p_id;
select avg(price) from products; 
select name from customers inner join orders on customers.cus_id=orders.cus_id;
select name from customers c where not exists(select * from orders o where c.cus_id=o.cus_id); 
select name from customers left join orders on customers.cus_id=orders.cus_id where orders.cus_id is null ;
select p_name from products where price> (select avg(price) from products);

#select name from customers  join orders where customers.cus_id=orders.cus_id and tamount >(select avg(tamount) from orders) ;
select name from customers c where exists(select * from orders o where c.cus_id=o.cus_id and tamount >  (select avg(tamount) from orders));


select ord_id from orders natural join customers where customers.addr=(select addr where cus_id=4); 
select ord_id from orders o where exists(select * from customers c where c.cus_id=o.cus_id and c.addr=(select addr where cus_id=4)); 





select name from customers c where exists(select * from orders o where c.cus_id=o.cus_id and  tamount=(select min(tamount) from orders));

select p_name,name from products natural join order_items natural join orders natural join customers where p_id=4;


select * from customers c where exists(select * from orders o where c.cus_id=o.cus_id and tamount>(select sum(tamount) from orders where c.addr=(select addr where cus_id=4)));















p_name
Hoodie
Backpack
Sunglasses
ord_id
4
5
6
7
8
name	count(ord_id)
Emily Johnson	1
Michael Brown	1
Sarah Davis	1
avg(price)	p_name
30.0000	Hoodie
60.0000	Dress
100.0000	Watch
50.0000	Backpack
25.0000	Sunglasses
avg(price)
53.0000
name
Emily Johnson
Michael Brown
Sarah Davis
name
Jessica Lee
Brain Wilson
name
Jessica Lee
Brain Wilson
p_name
Dress
Watch
name
Sarah Davis
ord_id
5
ord_id
5
name
Emily Johnson
p_name	name
Hoodie	Emily Johnson
cus_id	name	email	addr
5	Michael Brown	michael@example.com	321 Elm Avenue
6	Sarah Davis	sarah@example.com	654 Main Street